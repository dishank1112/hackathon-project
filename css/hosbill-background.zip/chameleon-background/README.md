# Chameleon background

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rowno/pen/EVEgJb](https://codepen.io/Rowno/pen/EVEgJb).

Dynamic background created from two squares rotating in opposite directions at an offset from each other.

See it in action at https://roland.codes/